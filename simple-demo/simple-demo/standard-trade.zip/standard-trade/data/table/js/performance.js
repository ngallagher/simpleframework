window.onload = function() {

   var paintTime = [];
   var roundTripTime = [];
   var networkTime = [];
   var maximumNetworkTime = [];
   var maximumPaintTime = [];
   var maximumRoundTripTime = [];
   var rowsChanged = [];
   var rowsChangedSum = [];
   var latencyDivision = [];
   var connections = 0;
   var attempts = 0;

   function connect() {
   var host =  window.document.location.hostname;
   var port = window.document.location.port;
   var scheme = window.document.location.protocol;
   var path = window.location.pathname;         
      var expression = "[\\?&]user=([^&#]*)";
      var regex = new RegExp(expression);
      var results = regex.exec(window.location.href);
      var address = "ws://";

   if(scheme.indexOf("https") == 0) {
      address = "wss://"
   }
      address += host;
   address += ":";
   address += port;
   address += "/";
   
   var segments = path.split("/");
   
   if(segments.length > 2) {
      address += segments[1] + "/";
   }
   address += "performance";
   address += "?user="; 
   address += results[1];
   
      var socket = new WebSocket(address);

      socket.onopen = function() {
         attempts = 1;
         connections++;
      };

      socket.onclose = function(message) {
         var exponent = Math.pow(2, attempts++);
         var interval = (exponent - 1) * 1000;
         var reference = connect();

         if (interval > 30 * 1000) {
            interval = 30 * 1000;
         }
         setTimeout(reference, interval);
      };

      socket.onmessage = function(message) {
         executeUpdate(message);
      };
   }


   var latencyDivisionChart = new CanvasJS.Chart("latencyDivision", {
      creditText: "",
      title: {
         text: "Latency Proportions"
      },
      legend: {
         fontFamily: "tahoma",
         fontSize: 12,
      },
      data: [{
         type: "pie",
         legendMarkerType: "circle",
         showInLegend: true,
         dataPoints: latencyDivision

      }]
   });
   var memoryDivision = [];

   var memoryDivisionChart = new CanvasJS.Chart("memoryDivision", {
      creditText: "",
      title: {
         text: "Memory Usage"
      },
      legend: {
         fontFamily: "tahoma",
         fontSize: 12,
      },
      data: [{
         type: "pie",
         legendMarkerType: "circle",
         showInLegend: true,
         dataPoints: memoryDivision

      }]
   });
   latencyDivisionChart.render();

   var paintTimeChart = new CanvasJS.Chart("paintTime", {
      creditText: "",
      /*backgroundColor: "#f5deb3",*/
      title: {
         text: "Paint Time"
      },
      legend: {
         fontFamily: "tahoma",
         horizontalAlign: "right", // "center" , "right"
         verticalAlign: "center", // "top" , "bottom"
         fontSize: 12
      },
      data: [{
         /*color: "#ff0000",*/
         type: "line",
         showInLegend: true,
         legendMarkerType: "circle",
         legendText: "Average",
         dataPoints: paintTime
      }, {
         /*color: "#00ff00",*/
         type: "line",
         legendMarkerType: "circle",
         showInLegend: true,
         legendText: "Maximum",
         dataPoints: maximumPaintTime
      }, ]
   });
   var roundTripTimeChart = new CanvasJS.Chart("roundTripTime", {
      creditText: "",
      /* backgroundColor: "#f5aaff",*/
      title: {
         text: "Round Trip Time"
      },
      legend: {
         fontFamily: "tahoma",
         horizontalAlign: "right", // "center" , "right"
         verticalAlign: "center", // "top" , "bottom"
         fontSize: 12
      },
      data: [{
            /* color: "#000000",*/
            type: "line",
            showInLegend: true,
            legendMarkerType: "circle",
            legendText: "Average",
            dataPoints: roundTripTime
         }, {
            /*color: "#00ff00",*/
            type: "line",
            legendMarkerType: "circle",
            showInLegend: true,
            legendText: "Maximum",
            dataPoints: maximumRoundTripTime
         },

      ]
   });
   var networkTimeChart = new CanvasJS.Chart("networkTime", {
      creditText: "",
      /* backgroundColor: "#f5aaff",*/
      title: {
         text: "Network Time"
      },
      legend: {
         fontFamily: "tahoma",
         horizontalAlign: "right", // "center" , "right"
         verticalAlign: "center", // "top" , "bottom"
         fontSize: 12
      },
      data: [{
            /* color: "#000000",*/
            type: "line",
            legendMarkerType: "circle",
            showInLegend: true,
            legendText: "Average",
            dataPoints: networkTime
         }, {
            /*color: "#00ff00",*/
            type: "line",
            legendMarkerType: "circle",
            showInLegend: true,
            legendText: "Maximum",
            dataPoints: maximumNetworkTime
         },

      ]
   });
   var rowsChangedChart = new CanvasJS.Chart("rowsChanged", {
      creditText: "",
      /*   backgroundColor: "#f5aa23",*/
      title: {
         text: "Price Changes"
      },
      legend: {
         fontFamily: "tahoma",
         horizontalAlign: "right", // "center" , "right"
         verticalAlign: "center", // "top" , "bottom"
         fontSize: 12
      },
      data: [{
            /*color: "#0000ff",*/
            type: "line",
            legendMarkerType: "circle",
            showInLegend: true,
            legendText: "Sample",
            dataPoints: rowsChanged
         }, {
            /*color: "#00ff00",*/
            type: "line",
            legendMarkerType: "circle",
            showInLegend: true,
            legendText: "Total",
            dataPoints: rowsChangedSum
         },


      ]
   });

   function executeUpdate(evt) {
      var data = evt.data.split(":");
      var point = data[1].split(",");
      var chart = null;
      var series = null;

      if (data[0] == 'paintTime') {
         chart = paintTimeChart;
         series = paintTime;
         latencyDivision[1] = {
            y: parseFloat(point[1]),
            legendText: "Paint"
         };
         latencyDivisionChart.render();
      }
      if (data[0] == 'roundTripTime') {
         chart = roundTripTimeChart;
         series = roundTripTime;
      }
      if (data[0] == 'rowsChangedSum') {
         chart = rowsChangedChart;
         series = rowsChangedSum;
      }
      if (data[0] == 'rowsChanged') {
         chart = rowsChangedChart;
         series = rowsChanged;
      }
      if (data[0] == 'networkTime') {
         chart = networkTimeChart;
         series = networkTime;
         latencyDivision[0] = {
            y: parseFloat(point[1]),
            legendText: "Network"
         };
         latencyDivisionChart.render();
      }
      if (data[0] == 'maximumRoundTripTime') {
         chart = networkTimeChart;
         series = maximumRoundTripTime;
      }
      if (data[0] == 'maximumPaintTime') {
         chart = paintTimeChart;
         series = maximumPaintTime;
      }
      if (data[0] == 'maximumNetworkTime') {
         chart = networkTimeChart;
         series = maximumNetworkTime;
      }
      if (data[0] == 'freeMemory') {
         memoryDivision[0] = {
            y: parseFloat(point[1]),
            legendText: "Free"
         };
         memoryDivisionChart.render();
      }
      if (data[0] == 'usedMemory') {
         memoryDivision[1] = {
            y: parseFloat(point[1]),
            legendText: "Used"
         };
         memoryDivisionChart.render();
      }
      if (series != null) {
         series.push({
            x: new Date(parseInt(point[0])),
            y: parseFloat(point[1]),
         });

         if (series.length > 500) {
            series.shift();
         }
      }
      if (chart != null) {
         chart.render();
      }
   }
   connect();
};
