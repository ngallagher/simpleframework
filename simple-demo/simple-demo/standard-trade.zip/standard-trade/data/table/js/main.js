var spinnerHiding = false;

function showMarket(){
   reconnect("best");
   document.getElementById("mainMarket").className = ""; 
   document.getElementById("mainMarket").className = "btn selected";
   document.getElementById("mainMyPrices").className = "";  
   document.getElementById("mainMyPrices").className = "btn";
   document.getElementById("litMyPrices").className = "";   
   document.getElementById("litMyPrices").className = "btn";
   document.getElementById("switchMyPrices").className = "";   
   document.getElementById("switchMyPrices").className = "btn";
   //location.href = "http://localhost:6060/grid.html?user=tom&company=ANZ&type=best";
}
function showMyPrices(){
   reconnect("company");
   document.getElementById("mainMarket").className = ""; 
   document.getElementById("mainMarket").className = "btn"; 
   document.getElementById("mainMyPrices").className = "";  
   document.getElementById("mainMyPrices").className = "btn selected";
   document.getElementById("litMyPrices").className = "";   
   document.getElementById("litMyPrices").className = "btn selected";
   document.getElementById("switchMyPrices").className = "";   
   document.getElementById("switchMyPrices").className = "btn selected";                  
   //location.href = "http://localhost:6060/grid.html?user=tom&company=ANZ&type=company";
}
function panic() {
   disconnect();
}
function finishedLoading() {
   if(spinnerHiding == false) {     
      var func = function(){
         hideSpinner();
      }
      window.setTimeout(func, 1000);
   }

}
function hideSpinner(){
   if(spinnerHiding == false) {
      spinnerHiding = true;   
      document.getElementById("overlay").style.visibility = 'hidden';
      //$('#topLayer').spin(false); 
   }
}
$(function () {
    
    //  $('#topLayer').spin({ lines: 10, length: 30, width: 20, radius: 40 }); 
      
    // -- LAYOUT
    var pstyle = 'background-color: #F5F6F7; overflow: hidden;';
    $('#mainLayout').w2layout({
        name: 'mainLayout',
        padding: 0,
        panels: [
            { type: 'top', size: '40px', style: pstyle },          
            { type: 'left', size: '40%', style: pstyle },        
            { type: 'right', size: '60%', style: pstyle },
            { type: 'bottom', size: '25px', style: pstyle }            
        ]
    });
    
    var pstyle = 'background-color: #F5F6F7; overflow: hidden;';
    $('#topLayout').w2layout({
        name: 'topLayout',
        padding: 0,
        panels: [                      
            { type: 'left', size: '40%', style: pstyle, content: "<div class='titleTop'>" +
"<table>" +
"<tr>" +
"<td>" +
"<span style='font-weight: bold; padding: 4px;'>Outright/EFP</span>" +
"</td>" +
"<td>" +
"<button class='btn panic' onclick='panic()'>Panic</button>" +
"</td>" +
"<td>" +
"<button class='btn'>Shrink</button>" +
"</td>" +
"<td>" +
"<button id='mainMarket' class='btn selected' onclick='showMarket()'>Market</button>" +
"</td>" +
"<td>" +
"<button id='mainMyPrices' class='btn notselected' onclick='showMyPrices()'>My Prices</button>" +
"</td>" +
"</tr>" +
"</table>" +
"</div>" },        
            { type: 'main', size: '30%', style: pstyle, content: "<div class='titleTop'>" +
"<table>" +
"<tr>" +
"<td>" +
"<span style='font-weight: bold; padding: 4px;'>Lit EFP</span>" +
"</td>" +
"<td>" +
"<button class='btn panic' onclick='panic()'>Panic</button>" +
"</td>" +
"<td>" +
"<button class='btn'>Shrink</button>" +
"</td>" +
"<td>" +
"<button id='litMyPrices' class='btn notselected' onclick='showMyPrices()'>My Levels</button>" +
"</td>" +
"</tr>" +
"</table>" +
"</div>" },
            { type: 'right', size: '30%', style: pstyle, content: "<div class='titleTop'>" +
"<table>" +
"<tr>" +
"<td>" +
"<span style='font-weight: bold; padding: 4px;'>Lit Switches</span>" +
"</td>" +
"<td>" +
"<button class='btn panic' onclick='panic()'>Panic</button>" +
"</td>" +
"<td>" +
"<button class='btn'>Shrink</button>" +
"</td>" +
"<td>" +
"<button id='switchMyPrices' class='btn notselected' onclick='showMyPrices()'>My Levels</button>" +
"</td>" +
"</tr>" +
"</table>" +
"</div>" }            
        ]
    });    

    var pstyle = 'background-color: #F5F6F7; overflow: hidden;';
    $('#blueLayout').w2layout({
        name: 'blueLayout',
        padding: 0,
        panels: [
            { type: 'left', size: '50%', style: pstyle },        
            { type: 'right', size: '50%', style: pstyle },
            { type: 'bottom', size: '40%', style: pstyle,
                name: 'tabs',
                tabs: {
                    active: 'tab1',
                    tabs: [
                        { id: 'tab1', caption: 'Market Monitor' },
                        { id: 'tab2', caption: 'Blotter' }
                    ],
                    onClick: function (event) {
                        if(event.target == 'tab1') {
                     w2ui['tabLayout'].content('main', w2ui['monitor']);                           
                        } else {
                     w2ui['tabLayout'].content('main', w2ui['blotter']);                           
                        }
                        w2ui['tabLayout'].refresh();
                    }
                }
            }            
        ]
    });

    $().w2grid({ 
        name: 'mainGrid'
    });
    
    $().w2grid({ 
        name: 'litEFPGrid'
    });
    
    $().w2grid({ 
        name: 'litSwitchGrid'
    });        
    
    $().w2grid({ 
        name: 'monitor', 
        columns: [                
            { field: 'action', caption: 'Action', size: '120px' },
            { field: 'volume', caption: 'Volume', size: '120px' },
            { field: 'security', caption: 'Dates', size: '120px' },
            { field: 'reference', caption: 'Ref', size: '120px' },
            { field: 'rate', caption: 'Rate', size: '120px' },
            { field: 'alerts', caption: 'Alerts', size: '120px' },
            { field: 'time', caption: 'Time', size: '120px' }          
        ],
        records: [
            { recid: 1, action: 'Offer Taken away', volume: 10, security: 'QTC25', reference: 'QTC24', rate: '11.75bp', time: '2:51 PM', style: 'background-color: #0000cd; color: #ffffff;' },
            { recid: 2, action: 'Bid Given away', volume: 10, security: 'NSW24', reference: 'NSW23', rate: '10.75bp', time: '2:11 PM', style: 'background-color: #0000cd; color: #ffffff;' },
            { recid: 3, action: 'Offer Taken away', volume: 9, security: 'QTC25', reference: 'QTC24', rate: '5.25bp', time: '2:10 PM', style: 'background-color: #0000cd; color: #ffffff;' },
            { recid: 4, action: 'Offer Taken away', volume: 10, security: 'QTC25', reference: 'QTC24', rate: '5.25bp', time: '1:59 PM', style: 'background-color: #0000cd; color: #ffffff;' },
            { recid: 5, action: 'Bid Given away', volume: 10, security: 'QTC25', reference: 'QTC24', rate: '11.75bp', time: '1:51 PM', style: 'background-color: #ffc0cb;' },
            { recid: 6, action: 'Broker Pool Closed', time: '9:05 AM', style: 'background-color: #000000; color: #ffffff;' }            
        ]
    });  
    
    $().w2grid({ 
        name: 'blotter', 
        columns: [                
            { field: 'ticket', caption: 'Ticket', size: '120px' },
            { field: 'action', caption: 'My Action', size: '120px' },
            { field: 'volume', caption: 'Volume', size: '120px' },
            { field: 'security', caption: 'Security', size: '120px' },
            { field: 'reference', caption: 'Ref', size: '120px' },
            { field: 'rate', caption: 'Rate', size: '120px' },
            { field: 'counterparty', caption: 'C/Party', size: '120px' },            
            { field: 'time', caption: 'Time', size: '120px' }              
        ]
    });    
    
    $('').w2layout({
        name: 'tabLayout',
        padding: 0,
        panels: [
            { type: 'main', size: '100%', style: pstyle, resizable: false }                 
        ]
    });    

    w2ui['mainLayout'].content('top', w2ui['topLayout']);
    w2ui['mainLayout'].content('left', w2ui['mainGrid']);
    w2ui['mainLayout'].content('right', w2ui['blueLayout']);
    
    w2ui['blueLayout'].content('left', w2ui['litEFPGrid']);   
    w2ui['blueLayout'].content('right', w2ui['litSwitchGrid']);
    
    w2ui['blueLayout'].content('bottom', w2ui['tabLayout']);
    w2ui['tabLayout'].content('main', w2ui['monitor']);  
        
    w2ui['mainLayout'].content('bottom', 
"<div style='background-color: #eee; padding: 2px 2px; font-family: Verdana,Arial,sans-serif; font-size: 11px;'> <span id='connection'>" +
"<img style='max-width: 100%; max-height: 25px; padding-left: 4px; padding-right: 4px; padding-top: 4px; padding-bottom: 4px;' src='img/failure.png'/>" +
"</span> Rows - <span id='rows'>" +
"</span> Changes - <span id='changes'>" +
"</span> Duration - <span id='duration'>" +
"</span>" +
"</div>");   
});
