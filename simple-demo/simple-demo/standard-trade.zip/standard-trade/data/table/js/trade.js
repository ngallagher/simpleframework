function refresh() {
   preloadImages([
    "img/ABN.png",
    "img/CS.png",
    "img/HSBC.png",
    "img/NAB.png",
    "img/RBC.png",
    "img/WBC.png",
    "img/ANZ.png",
    "img/DB.png",
    "img/MBL.png",
    "img/NOMURA.png",
    "img/RBS.png",
    "img/CITI.png",
    "img/failure.png",
    "img/ML.png",
    "img/pending.png",
    "img/success.png"]);  
   transpose();
   setInterval(transpose, 1000); 
}

function preloadImages(array) {
   for (var i = 0; i < array.length; i++) {
       var img = new Image();
       img.src = array[i];
   }
}

function extractParameter(name) {
   var source = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
   var expression = "[\\?&]" + source + "=([^&#]*)";
   var regex = new RegExp(expression);
   var results = regex.exec(window.location.href);

   if (results == null) {
      return "";
   }
   return results[1];
}

function transpose() {
   transposeTable("depthEFP");
   transposeTable("depthOutright");
}

function transposeTable(depthTable) {
   var table = document.getElementById(depthTable);
   var height = table.rows.length;
   var depth = [];

   for (var i = 0; i < height; i++) {
      var width = table.rows[0].cells.length;

      for (var j = 0; j < 10; j++) {
         var level = {};

         level['product'] = document.getElementById(depthTable + "_product_" + i).innerHTML;
         level['bidPrice'] = document.getElementById(depthTable + "_bidPrice" + j + "_" + i).innerHTML;
         level['offerPrice'] = document.getElementById(depthTable + "_offerPrice" + j + "_" + i).innerHTML;
         level['bidVolume'] = document.getElementById(depthTable + "_bidVolume" + j + "_" + i).innerHTML;
         level['offerVolume'] = document.getElementById(depthTable + "_offerVolume" + j + "_" + i).innerHTML;
         level['bidCompany'] = document.getElementById(depthTable + "_bidCompany" + j + "_" + i).innerHTML;
         level['offerCompany'] = document.getElementById(depthTable + "_offerCompany" + j + "_" + i).innerHTML;

         depth[j] = level;
      }
   }
   var transpose = document.getElementById(depthTable + "Transpose");
   var actual = transpose.rows.length;
   var required = depth.length;

   if (required > actual) {
      for (var i = actual; i <= required; i++) {
         transpose.insertRow(i);

         for (var j = 0; j < 4; j++) {
            transpose.rows[i].insertCell(j);
         }
         transpose.rows[i].cells[0].style.cssText = "vertical-align: top; padding: 5px; height: 40px; width: 10px;";
         transpose.rows[i].cells[1].style.cssText = "vertical-align: top; padding: 5px; height: 40px; width: 80px;";
         transpose.rows[i].cells[2].style.cssText = "vertical-align: top; padding: 5px; height: 40px; width: 200px;";
         transpose.rows[i].cells[3].style.cssText = "vertical-align: top; padding: 5px; height: 40px; width: 120px;";
      }
   }
   var side = extractParameter("side");
   var resultTemplates = [];
   var resultElements = [];
   var resultStyles = [];
   var changes = 0;

   for (var i = 0; i < depth.length; i++) {
      var resultRow = [];
      var resultElement = [];

      if (side == "bid") {
         var company = depth[i].bidCompany;
         var length = company.length;

         if (length > 0) {
            resultRow[0] = "<input type='checkbox'/>";
            resultRow[1] = "<b>" + depth[i].bidPrice + "bp</b>";
            resultRow[2] = "<img src='img/" + depth[i].bidCompany + ".png'/>";
            resultRow[3] = "Up to $" + depth[i].bidVolume + "mil";
         } else {
            resultRow[0] = "";
            resultRow[1] = "";
            resultRow[2] = "";
            resultRow[3] = "";
         }
      } else {
         var company = depth[i].offerCompany;
         var length = company.length;

         if (length > 0) {
            resultRow[0] = "<input type='checkbox'/>&nbsp;";
            resultRow[1] = "<b>" + depth[i].offerPrice + "bp</b>";
            resultRow[2] = "<img src='img/" + depth[i].offerCompany + ".png'/>";
            resultRow[3] = "Up to $" + depth[i].offerVolume + "mil";
         } else {
            resultRow[0] = "";
            resultRow[1] = "";
            resultRow[2] = "";
            resultRow[3] = "";
         }
      }
      for (var j = 0; j < 4; j++) {
         if (transpose.rows[i].cells[j].innerHTML != resultRow[j]) {
            changes++;
         }
         resultElement[j] = transpose.rows[i].cells[j];
      }
      resultTemplates[i] = resultRow;
      resultElements[i] = resultElement;
   }
   if (changes > 0) {
      for (var i = 0; i < depth.length; i++) {
         resultElements[i][0].innerHTML = resultTemplates[i][0];
         resultElements[i][1].innerHTML = resultTemplates[i][1];
         resultElements[i][2].innerHTML = resultTemplates[i][2];
         resultElements[i][3].innerHTML = resultTemplates[i][3];
      }
   }
}
var config = {
   tabs: {
      name: 'tabs',
      active: 'tab1',
      tabs: [{
         id: 'tab1',
         caption: 'Trade Request'
      }, {
         id: 'tab2',
         caption: 'Quote Request'
      }, {
         id: 'tab3',
         caption: 'My Allocations'
      }, {
         id: 'tab4',
         caption: 'Ticketing'
      }],
      onClick: function(event) {
         $('#tab-example .tab').hide();
         $('#tab-example #' + event.target).show();
      }
   }
}

$('#tabs').w2tabs(config.tabs);

var pstyle = 'background-color: #F5F6F7; overflow: hidden;';
var bstyle = 'background-color: #F5F6F7; overflow: hidden;';
var hstyle = 'background-color: #F5F6F7; overflow: hidden;';
$('#tradeRequest')
   .w2layout({
      name: 'tradeRequest',
      padding: 0,
      panels: [{
         type: 'top',
         size: '18%',
         style: hstyle
      }, {
         type: 'main',
         size: '40%',
         style: pstyle,
         content: "<table width='100%' height='100%'>" +
"<tr height='100%'>" +
"<td colspan='3'>" +
"<table width='100%' height='100%'>" +
"<tr align='center'>" +
"<td>" +
"<br>"+
"<table id='depthOutrightTranspose'/>" +
"<table id='depthOutright' />" +
"<table id='depthEFPTranspose'/>" +
"<table id='depthEFP' />" +
"</td>" +
"</tr>" +
"</table>" +
"</td>" +
"</tr>" +
"</table>"
      }, {
         type: 'bottom',
         size: '60px',
         style: bstyle,
         content: "<table style='width: 100%; height: 60px;'>" +
"<tr>" +
"<td width='5%'>" +
"</td>" +
"<td width='20%'>" +
"</td>" +
"<td width='50%' align='middle'>" +
"<button class='btn'>I Buy from UBS @ 14.20bp</button>" +
"</td>" +
"<td width='20%' align='right'>" +
"<button class='btn cancel'>Cancel</button>" +
"</td>" +
"<td width='5%'>" +
"</td>" +
"</tr>" +
"</table>"
      }]
   });
$('#tradeRequestControl')
   .w2layout({
      name: 'tradeRequestControl',
      padding: 0,
      panels: [{
         type: 'left',
         size: '16%',
         style: hstyle,
         content: "<div style='margin: 10px'>" +
"<table>" +
"<tr>" +
"<td>" +
"<input type='checkbox'/>&nbsp;Outright</td>" +
"</tr>" +
"<tr>" +
"<td>" +
"<input type='checkbox'/>&nbsp;EFP</td>" +
"</tr>" +
"<tr>" +
"<td>" +
"<input type='checkbox'/>&nbsp;Switch</td>" +
"</tr>" +
"<tr>" +
"<td>" +
"<input type='checkbox'/>&nbsp;MOC</td>" +
"</tr>" +
"</table>" +
"</div>"
      }, {
         type: 'main',
         size: '100%',
         style: pstyle
      }]
   });
$('#tradeRequestInfo').w2layout({
   name: 'tradeRequestInfo',
   padding: 0,
   panels: [{
      type: 'top',
      size: '60%',
      style: hstyle,
      content: "Top"
   }, {
      type: 'bottom',
      size: '30%',
      style: pstyle,
      content: "Bottom"
   }]
});

w2ui['tradeRequest'].content('top', w2ui['tradeRequestControl']);
w2ui['tradeRequestControl'].content('main', w2ui['tradeRequestInfo']);
w2ui['tradeRequestInfo'].content('top', "<div style='margin: 5px; padding: 5px; border: 1px solid #b5b6b7; border-radius: 5px;'>" +
"<form>" +
"<table cellpadding='2'>" +
"<tr>" +
"<td>Security 1</td>" +
"<td>" +
"</td>" +
"<td>" +
"</td>" +
"<td>" +
"</td>" +
"</tr>" +
"<tr>" +
"<td>" +
"<select style='width: 160px'>" +
"<option>CGS 4.25 Apr-26</option>" +
"<option>CGS 4.25 Map-16</option>" +
"<option>CGS 5.25 Jun-26</option>" +
"<option>CGS 3.25 Apr-22</option>" +
"<option>CGS 3.25 Oct-34</option>" +
"<option>CGS 4.25 Sep-26</option>" +
"</select>" +
"</td>" +
"<td>" +
"&nbsp;<input type='checkbox'/>&nbsp;I Buy</td>" +
"<td>" +
"&nbsp;<input type='checkbox'/>&nbsp;I Sell</td>" +
"<td>&nbsp;Volume $&nbsp;<input style='height: 30px; width: 60px;' type='text'/>&nbsp;mil</td>" +
"</tr>" +
"</table>" +
"</form>" +
"</div>");

w2ui['tradeRequestInfo'].content('bottom', "<form>" +
"<table cellpadding='2'>" +
"<tr>" +
"<td>Futures:&nbsp;</td>" +
"<td>" +
"<select style='width: 100px'>" +
"<option>XYB Sep</option>" +
"<option>XYB Jun</option>" +
"</select>" +
"</td>" +
"<td>&nbsp;Contracts:&nbsp;</td>" +
"<td>" +
"<input style='height: 30px; width: 60px;' type='text'/>" +
"</td>" +
"<td>&nbsp;Account:&nbsp;</td>" +
"<td>" +
"<select style='width: 100px'>" +
"<option>Account...</option>" +
"<option>OIS</option>" +
"<option>Swap</option>" +
"</select>" +
"</td>" +
"</tr>" +
"</table>" +
"</form>");

$('#tab1').show();

window.addEventListener("load", refresh, false);