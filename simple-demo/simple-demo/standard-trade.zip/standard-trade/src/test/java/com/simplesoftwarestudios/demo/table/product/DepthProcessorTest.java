package com.simplesoftwarestudios.demo.table.product;

import com.simplesoftwarestudios.demo.table.product.DepthDebugger;
import com.simplesoftwarestudios.demo.table.product.DepthProcessor;
import com.simplesoftwarestudios.demo.table.product.Price;
import com.simplesoftwarestudios.demo.table.product.PriceType;
import com.simplesoftwarestudios.demo.table.product.Side;

import junit.framework.TestCase;

public class DepthProcessorTest extends TestCase {
   
   public void testDepth() throws Exception {
      DepthDebugger debugger = new DepthDebugger();
      DepthProcessor processor = new DepthProcessor(debugger);
      
      processor.update(new Price("X", PriceType.EFP, Side.BID, "HSBC", 10.1, 100000L));
      processor.update(new Price("X", PriceType.EFP, Side.OFFER, "ANZ", 11.1, 100000L));
      processor.update(new Price("X", PriceType.EFP, Side.BID, "ANZ", 11.1, 100000L));
      processor.update(new Price("X", PriceType.EFP, Side.BID, "DB", 12.1, 100000L));
      processor.update(new Price("X", PriceType.EFP, Side.BID, "DB", 9.1, 100000L));
      processor.update(new Price("X", PriceType.EFP, Side.BID, "ANZ", 8.1, 100000L));
      processor.update(new Price("X", PriceType.EFP, Side.OFFER, "HSBC", 11.0, 100000L));      
   }

}
