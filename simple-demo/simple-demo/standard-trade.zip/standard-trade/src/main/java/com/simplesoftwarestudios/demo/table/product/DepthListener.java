package com.simplesoftwarestudios.demo.table.product;

public interface DepthListener {
   void update(Depth depth);
}
