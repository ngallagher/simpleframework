package com.simplesoftwarestudios.demo.table.product;

public enum PriceType {
   EFP,
   OUTRIGHT;
}
