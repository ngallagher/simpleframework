package com.simplesoftwarestudios.demo.table.format;

public interface CellFormatter {
   String formatCell(Object value);
}
