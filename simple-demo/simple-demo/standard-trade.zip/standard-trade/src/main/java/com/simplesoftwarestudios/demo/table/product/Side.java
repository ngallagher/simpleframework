package com.simplesoftwarestudios.demo.table.product;

public enum Side {
   BID,
   OFFER;
}
