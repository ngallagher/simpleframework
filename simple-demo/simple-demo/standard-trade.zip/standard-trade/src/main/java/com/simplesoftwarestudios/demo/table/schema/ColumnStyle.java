package com.simplesoftwarestudios.demo.table.schema;

public interface ColumnStyle {
   String getName();
   String getTemplate();
   String getStyle();
   String getTitle();
   boolean isResizable();
   boolean isSortable();
   boolean isHidden();
   int getWidth();
}
