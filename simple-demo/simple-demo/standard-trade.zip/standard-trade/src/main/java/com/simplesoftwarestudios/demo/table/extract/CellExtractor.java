package com.simplesoftwarestudios.demo.table.extract;

public interface CellExtractor<T> {
   Object extract(T value);
}
