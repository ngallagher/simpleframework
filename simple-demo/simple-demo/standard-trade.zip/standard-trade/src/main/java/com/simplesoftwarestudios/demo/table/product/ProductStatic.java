package com.simplesoftwarestudios.demo.table.product;

public class ProductStatic {

   private final String name;
   
   public ProductStatic(String name) {
      this.name = name;
   }
   
   public String getName() {
      return name;
   }
}
