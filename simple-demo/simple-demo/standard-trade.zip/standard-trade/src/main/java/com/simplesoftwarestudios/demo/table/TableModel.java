package com.simplesoftwarestudios.demo.table;

public interface TableModel {
   TableSubscription subscribe(Query query);
}
