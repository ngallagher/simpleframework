package com.simplesoftwarestudios.demo.table.service;

import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.concurrent.Executor;

import org.apache.log4j.Logger;
import org.simpleframework.common.thread.Daemon;
import org.simpleframework.http.socket.FrameChannel;
import org.simpleframework.http.socket.Session;

import com.simplesoftwarestudios.demo.table.Query;
import com.simplesoftwarestudios.demo.table.TableCursor;
import com.simplesoftwarestudios.demo.table.TableModel;
import com.simplesoftwarestudios.demo.table.TableSubscription;
import com.simplesoftwarestudios.demo.table.extract.RowExtractor;
import com.simplesoftwarestudios.demo.table.format.RowFormatter;
import com.simplesoftwarestudios.demo.table.schema.TableSchema;

public class TableUpdater extends Daemon {   
   
   private static final Logger LOG = Logger.getLogger(TableUpdater.class);
  
   private final Set<TableConnection> ready;   
   private final RowExtractor extractor;
   private final RowFormatter formatter;
   private final Executor executor;
   private final TableSchema schema;
   private final TableModel model;
   
   public TableUpdater(TableModel model, TableSchema schema, RowExtractor extractor, RowFormatter formatter, Executor executor) {    
      this.ready = new CopyOnWriteArraySet<TableConnection>();
      this.executor = executor;
      this.formatter = formatter;
      this.extractor = extractor;      
      this.schema = schema;
      this.model = model;      
   }
   
   public void acknowledge(Session session, String table, long number) {
      for(TableConnection connection : ready) {
         try {
            connection.acknowledge(session, table, number);
         } catch(Exception e) {
            LOG.info("Could not acknowledge table " + table, e);
         }
      }
   }
   
   public void refresh(Session session) {
      for(TableConnection connection : ready) {
         try {
            connection.refresh(session);
         } catch(Exception e) {
            LOG.info("Could not refresh session", e);
         }
      }
   }
  

   public void subscribe(FrameChannel socket, Query client) {
      TableSubscription subscription = model.subscribe(client);
      
      if(subscription != null) {
         TableSession session = new TableSession(socket);
         TableCursor cursor = new TableCursor(subscription, schema, extractor, formatter);
         TableConnection connection = new TableConnection(cursor, session, schema);
         
         ready.add(connection);
      }
   }
   
   public void run() {
      while(true) {
         try {
            Thread.sleep(200);
         
            for(TableConnection connection : ready) {
               long time = System.currentTimeMillis();
               try {
                  ready.remove(connection);
                  executor.execute(new TableRefresher(connection));
               }catch(Exception e){
                  LOG.info("ERROR AFTER " +(System.currentTimeMillis() - time) + " ", e);                 
                  ready.remove(connection);
               }
            }
         } catch(Exception e) {
            LOG.info("Could not execute update", e);            
         }
      }
   }
      
   public class TableRefresher implements Runnable {
      
      private final TableConnection connection;
      
      public TableRefresher(TableConnection connection) {
         this.connection = connection;
      }
      
      public void run() {
         try {            
            connection.update();
            ready.add(connection);
         } catch(Exception e) {
            LOG.info("Could not execute refresh", e);
         }
      }
      
   }
   
}
