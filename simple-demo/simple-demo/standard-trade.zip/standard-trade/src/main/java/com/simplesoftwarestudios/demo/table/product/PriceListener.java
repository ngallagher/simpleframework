package com.simplesoftwarestudios.demo.table.product;

public interface PriceListener {
   void update(Price price);
}
