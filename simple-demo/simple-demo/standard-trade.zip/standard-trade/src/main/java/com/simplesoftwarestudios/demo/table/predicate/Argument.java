package com.simplesoftwarestudios.demo.table.predicate;

public interface Argument {
   Object getAttribute(String name);
}
